---
external help file: PSCloudFlare-help.xml
online version: https://github.com/zloeber/PSCloudFlare
schema: 2.0.0
---

# Get-CFRequestData

## SYNOPSIS
Gets the parameters for a request to the Cloudflare API.

## SYNTAX

```
Get-CFRequestData
```

## DESCRIPTION
Gets the parameters for a request to the Cloudflare API.

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```
TBD
```

## PARAMETERS

## INPUTS

## OUTPUTS

## NOTES
Author: Zachary Loeber

## RELATED LINKS

[https://github.com/zloeber/PSCloudFlare](https://github.com/zloeber/PSCloudFlare)

